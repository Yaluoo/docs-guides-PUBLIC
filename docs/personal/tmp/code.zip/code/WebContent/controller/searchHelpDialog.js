//Dialog
sap.ui
		.define(
			[
					"./BaseController",
					"sap/ui/base/Object",
					"./messages",
					'sap/ui/core/Fragment',
					'sap/ui/model/Filter',
					"sap/ui/Device",
					"./designMode",
					"yaluooFI01/model/poster",
					"yaluooFI01/model/formatter"
			],
			function(BaseController, Object, messages, Fragment, Filter, Device, designMode, poster, formatter) {
				"use strict";

				return Object
						.extend(
							"yaluooFI01.controller.searchHelpDialog",
							{

								formatter : formatter,

								// ������
								constructor : function(oParentView) {
									this._oParentView = oParentView;
									this._oController  = this._oParentView.getController();
									this._oViewModel = this._oParentView.getModel();
									this._ResourceBundle = this._oParentView.getModel("i18n").getResourceBundle();
								},

								// �򿪵����¼�
								openDialog : function() {

									if (!this._oDialog) {
										this._oDialog = sap.ui.xmlfragment(this._oParentView.getId(), "yaluooFI01.view.searchHelpDialog", this);
										designMode.syncStyleClass(this._oParentView, this._oDialog);
										this._oParentView.addDependent(this._oDialog);
									}

									this._oDialog.open();
								},

								// ȡ���¼�
								onCancelAction : function() {
									this._oDialog.close();
								},
								
								// ȷ���¼�
								onOkAction : function() {
									this._oDialog.close();
									var hcode = this._oViewModel.getProperty("/appProperties/hcode");
								},
					
								// Ա����Ϣ  ��ʾ����
								setFC1Visible : function(b, h) {
									if (h == "AccountNo") {
										return true;
									}
									return false;
								},
								
								// Ա����Ϣ  ��ʾ����
								setFC2Visible : function(b, h) {
									if (h == "Category") {
										return true;
									}
									return false;
								},
								
								// flyback����  ��ʾ����
								setFC3Visible : function(b, h) {
									if (h == "ProjectId") {
										return true;
									}
									return false;
								},
								
								// flyback����  ��ʾ����
								setFC4Visible : function(b, h) {
									if (h == "CustomerNo") {
										return true;
									}
									return false;
								},
								
								// flyback����  ��ʾ����
								setFC5Visible : function(b, h) {
									if (h == "SupplierNo") {
										return true;
									}
									return false;
								},
								
								// ������ʾ���ڴ�С
								setContentWidth : function(b, h){
									return "auto";
								},
								
								// ������ʾ���ڵı���
								setTitle : function(v){
									if(v == "AccountNo"){
										return "�˻������������";
									}
									if(v == "Category"){
										return "��֧�����������";
									}
									if(v == "CustomerNo"){
										return "�ͻ������������";
									}
									if(v == "SupplierNo"){
										return "��Ӧ�̱����������";
									}
									if(v == "ProjectId"){
										return "��Ŀ��������";
									}
								},
							
								
								// ����ȷ�ϰ�ť��ʾ����
								setConfirmBtnVisible : function(b, h){
									if(b == "DP" && h == "ImportFlyback"){
										return true;
									}
									return false;
								},
								
								onConfirmAction : function(){
									
									
								},
								
								
								handleSelectItem : function(oEvent){
									var selectSet = this._oViewModel.getProperty(oEvent.getSource().getBindingContextPath());
									this.setItemValue(selectSet);
									this._oDialog.close();
								},
								
								
								// ����ѯ��������Ŀ�ֶ�
								setItemValue : function(selectSet){
									var hcode = this._oViewModel.getProperty("/appProperties/hcode");
									var bcode = this._oViewModel.getProperty("/appProperties/bcode");
									switch(hcode){
										case 'AccountNo':
											this._oViewModel.setProperty("/" + bcode.toLowerCase()+"Set/AccountNo", selectSet.AccountNo, false);
											this._oViewModel.setProperty("/" + bcode.toLowerCase()+"Set/AccountDescription", selectSet.AccountDescription, false);
											break;
										case 'Category':
											this._oViewModel.setProperty("/" + bcode.toLowerCase()+"Set/Category", selectSet.Category, false);
											this._oViewModel.setProperty("/" + bcode.toLowerCase()+"Set/CategoryDescription", selectSet.CategoryDescription, false);
											break;
										case 'ProjectId':
											this._oViewModel.setProperty("/" + bcode.toLowerCase()+"Set/ProjectId", selectSet.ProjectId, false);
											this._oViewModel.setProperty("/" + bcode.toLowerCase()+"Set/ProjectAlias", selectSet.ProjectAlias, false);
											break;
										case 'CustomerNo':
											this._oViewModel.setProperty("/" + bcode.toLowerCase()+"Set/CustomerNo", selectSet.CustomerNo, false);
											this._oViewModel.setProperty("/" + bcode.toLowerCase()+"Set/CustomerName", selectSet.CustomerName, false);
											break;
										case 'SupplierNo':
											this._oViewModel.setProperty("/" + bcode.toLowerCase()+"Set/SupplierNo", selectSet.SupplierNo, false);
											this._oViewModel.setProperty("/" + bcode.toLowerCase()+"Set/SupplierName", selectSet.SupplierName, false);
											break;
										default :
											break;
									}
									if(this._oParentView.byId("input"+hcode).getValueState()){
										this._oParentView.byId("input"+hcode).setValueState("None");
									}
									
								},
								
								// ���ú�̨��ѯ���ں���
								handleQueryVacation : function(){
									this._oViewModel.setProperty("/appProperties/fcode","GET_VACATION",false);
									poster.doPost(this._oParentView);
								},
								
								// ������������
								onSearchParas : function(evt) {
									var aFilters = [];
									var aQuerys = [];
									var query = evt.getSource().getValue();
									var queryId = evt.getParameter("id");
									queryId = queryId.split("--")[1];
									aQuerys = queryId.split("-");
									if (query && query.length > 0) {
										var afilter = [];
										for (var i = 0; i < aQuerys.length; i++) {
											afilter.push(new Filter(aQuerys[i], sap.ui.model.FilterOperator.Contains, query));
										}
										var allFilters = new Filter(afilter, false);// falseΪ����
										aFilters.push(allFilters);
									}
									var TabId = queryId + "Tab";
									var binding = this._oParentView.byId(TabId).getBinding("items");
									binding.filter(aFilters);
								},
								
								
								// �ص��ɹ������¼�
								onPostSuccess : function(oContext) {
									oContext.getEventBus().publish("yaluooFI01", "postSuccess", oContext);
								},

								// �ص�ʧ�ܷ����¼�
								onPostError : function(oContext) {
									oContext.getEventBus().publish("yaluooFI01", "postError", oContext);
								},
							});
			});