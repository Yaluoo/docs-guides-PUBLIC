sap.ui.define([
		"yaluooFI01/controller/BaseController",
		"yaluooFI01/controller/designMode",
		"yaluooFI01/model/formatter",
		"yaluooFI01/controller/messages",
		"yaluooFI01/model/poster",
		"yaluooFI01/controller/searchHelpDialog",
], function(BaseController, designMode, formatter, messages, poster, searchHelpDialog) {
	"use strict";
	return BaseController.extend("yaluooFI01.controller.myAccountBalance", {

		// ��ʼ��
		onInit : function() {
			this._Controller = this;
			this._ResourceBundle = this.getModel("i18n").getResourceBundle();
			this.getView().setModel(this.getOwnerComponent().getModel("myAccount"), "myAccount");
			this.getView().setModel(this.getOwnerComponent().getModel("accountBalance"), "accountBalance");
		},

		onAfterRendering : function() {
		},

	});
});