sap.ui.define([ "yaluooFI01/controller/BaseController", "yaluooFI01/controller/designMode", "sap/ui/table/Table", "sap/ui/table/Column",
        "sap/m/Text", "sap/m/MessageBox", "sap/m/Dialog", "sap/m/OverflowToolbar", "sap/m/Button", "sap/m/ComboBox", "sap/ui/core/ListItem",
        "sap/ui/model/Filter", "sap/ui/core/Fragment" ], function (BaseController, designMode, Table, Column, Text, MessageBox, Dialog,
        OverflowToolbar, Button, ComboBox, ListItem, Filter, Fragment) {
    "use strict";
    return BaseController.extend("yaluooFI01.controller.costConfirm", {

        onInit : function () {

            var aMethod = [ {
                "key" : "DEFAULT",
                "text" : "Ĭ��"
            }, {
                "key" : "INCOME_CURRENT",
                "text" : "��������"
            }, {
                "key" : "INCOME_F3",
                "text" : "������������"
            }, {
                "key" : "INCOME_F6",
                "text" : "������������"
            }, {
                "key" : "INCOME_F12",
                "text" : "��ʮ���������� "
            }, {
                "key" : "INCOME",
                "text" : "�����ܽ��"
            }, {
                "key" : "COST_CURRENT",
                "text" : "���ڳɱ�"
            }, {
                "key" : "COST_F3",
                "text" : "�������³ɱ�"
            }, {
                "key" : "COST_F6",
                "text" : "�������³ɱ�"
            }, {
                "key" : "COST_F12",
                "text" : "��ʮ�����³ɱ� "
            }, {
                "key" : "COST",
                "text" : "�ɱ��ܽ��"
            }, {
                "key" : "INVOICE_CURRENT",
                "text" : "���ڿ�Ʊ��� "
            }, {
                "key" : "INVOICE_LAST",
                "text" : "���¿�Ʊ��� "
            }, {
                "key" : "INVOICE_F3",
                "text" : "�������¿�Ʊ��� "
            }, {
                "key" : "INVOICE_F6",
                "text" : "�������¿�Ʊ��� "
            }, {
                "key" : "INVOICE_F12",
                "text" : "��ʮ�����¿�Ʊ��� "
            }, {
                "key" : "INVOICE",
                "text" : "��Ʊ�ܽ��"
            }, {
                "key" : "ALLOWANCE_CURRENT",
                "text" : "���ڲ���"
            }, {
                "key" : "ALLOWANCE_F3",
                "text" : "�������²���"
            }, {
                "key" : "ALLOWANCE_F6",
                "text" : "�������²���"
            }, {
                "key" : "ALLOWANCE_F12",
                "text" : "��ʮ�����²��� "
            }, {
                "key" : "ALLOWANCE",
                "text" : "�����ܽ�� "
            } ];

            this._JSONModel = this.getModel();

            this._JSONModel.setData({
                period : "",
                periodEditable : true,
                periodState : "Error",
                directCostCounter : 0,
                indirectCostCounter : 0,
                confirmMethod : aMethod,
                methodSelected : "DEFAULT",
                methodButtonText : "Ĭ��",
                calculatedIndirectCost : []
            });

        },

        onAfterRendering : function () {

        },

        checkPeriod : function (oEvent) {

            var oController = this;
            var nPeriod = oEvent.getSource().getValue();

            if (isNaN(nPeriod)) {
                oController._JSONModel.setProperty("/periodState", "Error");
                return;
            } else {
                oController._JSONModel.setProperty("/periodState", "None");
            }

            if (nPeriod.length < 6) {
                oController._JSONModel.setProperty("/periodState", "Error");
                return;
            } else {
                oController._JSONModel.setProperty("/periodState", "None");
            }

            if (parseInt(nPeriod.substring(0, 4)) === 0 || parseInt(nPeriod.substring(4)) === 0 || parseInt(nPeriod.substring(4)) > 12) {
                oController._JSONModel.setProperty("/periodState", "Error");
                return;
            } else {
                oController._JSONModel.setProperty("/periodState", "None");
            }

            oController._JSONModel.setProperty("/periodEditable", false);
        },

        methodChanged : function (oEvent) {
            oEvent.getSource().getModel().setProperty("/methodButtonText", oEvent.getParameters().selectedItem.getText());
        },

        formatProjectStatus : function (v) {
            v = v ? v : "";
            switch (v) {
            case "ONG":
                return "������";
            case "PRC":
                return "Ԥ�ر�";
            case "TEC":
                return "�����ر�";
            case "CLD":
                return "����ر�";
            case "HUG":
                return "����";
            default:
            }
        },

        formatProjectPayType : function (v) {
            v = v ? v : "";
            switch (v) {
            case "MS":
                return "��̱�";
            case "TM":
                return "����";
            default:
            }
        },

        formatDetailCheck : function (v) {
            switch (v) {
            case true:
                return "��";
            case false:
                return "��";
            default:
                return "��";
            }
        },

        formatCostType : function (v) {
            switch (v) {
            case "A":
                return "ֱ��";
            case "B":
                return "���";
            case "Z":
                return "�ڳ�";
            default:
                return "";
            }
        },

        toDirectCostStep : function () {
            this._showDirectCost(this);
        },

        _showDirectCost : function (oController) {
            var oDirectCostTable = oController.byId("directCostTable");
            var aFilters = [];
            aFilters.push(new Filter("Period", sap.ui.model.FilterOperator.EQ, oController._JSONModel.getProperty("/period")));
            var fDirectCostDataReceived = function (oEvent) {
                var iDirectCostCounter = oEvent.getSource().getLength();
                var oDirectCostTable = oController.byId("directCostTable");
                oController._JSONModel.setProperty("/directCostCounter", iDirectCostCounter);
                oDirectCostTable.setMinAutoRowCount(iDirectCostCounter > 1 ? iDirectCostCounter : 1);
                oDirectCostTable.setVisibleRowCount(iDirectCostCounter > 1 ? iDirectCostCounter : 1);
            };

            oDirectCostTable.bindRows({
                model : "yaluooFI01",
                path : "/directCostSet",
                filters : aFilters,
                events : {
                    dataReceived : fDirectCostDataReceived
                }
            });

            oDirectCostTable.clearSelection();

        },

        toIndirectCostStep : function () {
            this._showIndirectCost(this);
        },

        _showIndirectCost : function (oController) {

            var oIndirectCostTable = oController.byId("indirectCostTable");
            var aFilters = [];
            aFilters.push(new Filter("Period", sap.ui.model.FilterOperator.EQ, oController._JSONModel.getProperty("/period")));
            var fOnIndirectCostDataReceived = function (oEvent) {
                var iIndirectCostCounter = oEvent.getSource().getLength();
                oController._JSONModel.setProperty("/indirectCostCounter", iIndirectCostCounter);
                oIndirectCostTable.setMinAutoRowCount(iIndirectCostCounter > 1 ? iIndirectCostCounter : 1);
                oIndirectCostTable.setVisibleRowCount(iIndirectCostCounter > 1 ? iIndirectCostCounter : 1);
            };

            oIndirectCostTable.bindRows({
                model : "yaluooFI01",
                path : "/indirectCostSet",
                filters : aFilters,
                events : {
                    dataReceived : fOnIndirectCostDataReceived
                }
            });
            oIndirectCostTable.clearSelection();

            var oCostElementTable = oController.byId("costElementTable");
            aFilters = [];
            aFilters.push(new Filter("Period", sap.ui.model.FilterOperator.EQ, oController._JSONModel.getProperty("/period")));
            var fOnCostElementDataReceived = function (oEvent) {
                var iCostElementCounter = oEvent.getSource().getLength();
                oCostElementTable.setMinAutoRowCount(iCostElementCounter > 1 ? iCostElementCounter : 1);
                oCostElementTable.setVisibleRowCount(iCostElementCounter > 1 ? iCostElementCounter : 1);
            };

            oCostElementTable.bindRows({
                model : "yaluooFI01",
                path : "/costElementSet",
                filters : aFilters,
                events : {
                    dataReceived : fOnCostElementDataReceived
                }
            });
            oCostElementTable.clearSelection();

        },

        showCostList : function () {

            var oController = this;
            var oCostListTable = oController.byId("costListTable");
            var aFilters = [];
            aFilters.push(new Filter("Period", sap.ui.model.FilterOperator.EQ, oController._JSONModel.getProperty("/period")));
            var fOnCostListDataReceived = function (oEvent) {
                var iCostListCounter = oEvent.getSource().getLength();
                oCostListTable.setMinAutoRowCount(iCostListCounter > 1 ? iCostListCounter : 1);
                oCostListTable.setVisibleRowCount(iCostListCounter > 1 ? iCostListCounter : 1);
            };

            oCostListTable.bindRows({
                model : "yaluooFI01",
                path : "/costSet",
                filters : aFilters,
                events : {
                    dataReceived : fOnCostListDataReceived
                }
            });

        },

        showCostSummary : function () {

            var oController = this;
            var oCostSummaryTable = oController.byId("costSummaryTable");
            var aFilters = [];
            aFilters.push(new Filter("Period", sap.ui.model.FilterOperator.EQ, oController._JSONModel.getProperty("/period")));
            var fOnCostSummaryDataReceived = function (oEvent) {
                var iCostSummaryCounter = oEvent.getSource().getLength();
                oCostSummaryTable.setMinAutoRowCount(iCostSummaryCounter > 1 ? iCostSummaryCounter : 1);
                oCostSummaryTable.setVisibleRowCount(iCostSummaryCounter > 1 ? iCostSummaryCounter : 1);
            };

            oCostSummaryTable.bindRows({
                model : "yaluooFI01",
                path : "/costSummarySet",
                filters : aFilters,
                events : {
                    dataReceived : fOnCostSummaryDataReceived
                }
            });

        },

        _getTableSelectedData : function (oTable) {
            var aSelectedCost = [];
            var fGetSelectCost = function (i) {
                aSelectedCost.push(oTable.getContextByIndex(i).getObject());
            };
            oTable.getSelectedIndices().forEach(fGetSelectCost);
            return aSelectedCost;
        },

        _postCost : function (oController, oRequest, fSuccess, fError) {

            // var fOnPreviewCostDataReceived = function (oEvent) {
            // var iPreviewCostCounter = oEvent.getSource().getLength();
            // oController.oPreviewCostTable.setMinAutoRowCount(iPreviewCostCounter > 1 ? iPreviewCostCounter : 1);
            // oController.oPreviewCostTable.setVisibleRowCount(iPreviewCostCounter > 1 ? iPreviewCostCounter : 1);
            // };
            //
            // oController.oPreviewCostTable.bindRows({
            // model : "yaluooFI01",
            // path : "/costSet",
            // events : {
            // dataReceived : fOnPreviewCostDataReceived
            // }
            // });

            var sUrl = "/costConfirmHSet";
            var mParameters = {
                expand : "costConfirmHSet/np_costH2cost,costConfirmHSet/np_costH2ms",
                success : function (oData, response) {
                    oController._JSONModel.setProperty("/calculatedIndirectCost", oData.np_costH2cost.results, false);
                    // oController.setBusy(false);
                    if (fSuccess) {
                        fSuccess(oController);
                    }
                }.bind(oController),
                error : function (oError) {
                    // this._Controller.setBusy(false);
                    // this._Controller.oError = oError;
                    // messages.convertODataErrorMessage(this._Controller);
                    // this._Controller.updateObligatory();
                    if (fError) {
                        fError(oController);
                    }
                }.bind(oController)
            };
            oController.getModel("yaluooFI01").create(sUrl, oRequest, mParameters);
        },

        _previewCost : function (oController) {

            if (!oController.previewCostDialog) {
                Fragment.load({
                    name : "yaluooFI01.view.costConfirm",
                    controller : oController
                }).then(function (oDialog) {
                    oController.previewCostDialog = oDialog;
                    designMode.syncStyleClass(oController.getView(), oController.previewCostDialog);
                    oController.getView().addDependent(oController.previewCostDialog);
                    oController._openCostConfirmDialog();
                }.bind(oController));
            } else {
                oController._openCostConfirmDialog();
            }

        },

        confirmDirectCost : function () {

            var oController = this;
            var oDirectCostTable = oController.byId("directCostTable");
            var aSelectedCost = oController._getTableSelectedData(oDirectCostTable);

            if (aSelectedCost.length === 0) {
                MessageBox.error("δѡ��ɱ���¼", {
                    styleClass : designMode.getCompactCozyClass()
                });
                return false;
            }

            var oRequest = {
                Action : "SAVE",
                Period : oController._JSONModel.getProperty("/period"),
                Method : oController._JSONModel.getProperty("/methodSelected"),
                ProjectId : "",
                np_costH2cost : aSelectedCost,
                np_costH2element : [],
                np_costH2ms : []
            };

            MessageBox.confirm("ȷ����ѡ�ɱ���", {
                styleClass : designMode.getCompactCozyClass(),
                onClose : function (sAction) {
                    sAction === "OK" ? oController._postCost(oController, oRequest, oController._showDirectCost) : "";
                }
            });

        },

        _calculateIndirectCost : function () {

            var oController = this;
            var oIndirectCostTable = oController.byId("indirectCostTable");
            var oCostElementTable = oController.byId("costElementTable");
            var aSelectedCost = oController._getTableSelectedData(oIndirectCostTable);
            var aSelectedCostElement = oController._getTableSelectedData(oCostElementTable);

            if (aSelectedCost.length === 0) {
                MessageBox.error("δѡ��ɱ���¼", {
                    styleClass : designMode.getCompactCozyClass()
                });
                return false;
            }

            if (aSelectedCostElement.length === 0) {
                MessageBox.error("δѡ���̯����", {
                    styleClass : designMode.getCompactCozyClass()
                });
                return false;
            }

            var oRequest = {
                Action : "CALC",
                Period : oController._JSONModel.getProperty("/period"),
                Method : oController._JSONModel.getProperty("/methodSelected"),
                ProjectId : "",
                np_costH2cost : aSelectedCost,
                np_costH2element : aSelectedCostElement,
                np_costH2ms : []
            };

            oController._postCost(oController, oRequest);
            return true;

        },

        previewCalculatedIndirectCost : function (oEvent) {
            var oController = this;
            if (oController._calculateIndirectCost()) {
                oController._previewCost(oController);
            }
        },

        _openCostConfirmDialog : function () {
            var oController = this;
            oController.previewCostDialog.open();
        },

        _closeCostConfirmDialog : function () {
            var oController = this;
            oController.previewCostDialog.close();
        },

        _afterConfirmIndirectCost : function (oController) {
            oController._showIndirectCost(oController);
            oController.previewCostDialog.close();
        },

        confirmIndirectCost : function () {
            var oController = this;
            var oRequest = {
                Action : "SAVE",
                Period : oController._JSONModel.getProperty("/period"),
                Method : "",
                ProjectId : "",
                np_costH2cost : oController._JSONModel.getProperty("/calculatedIndirectCost"),
                np_costH2element : [],
                np_costH2ms : []
            };
            oController._postCost(oController, oRequest, oController._afterConfirmIndirectCost);
        },

        changeIndirectCostTableSelection : function (oEvent) {

            var oTable = oEvent.getSource();
            var iRowIndex = oEvent.getParameter("rowIndex");
            var oRowContext = oEvent.getParameter("rowContext");
            var aRowIndices = oEvent.getParameter("rowIndices");
            var bSelectAll = oEvent.getParameter("selectAll");
            var iLength = oTable.getBinding("rows").getLength();
            var bSelected = oTable.isIndexSelected(iRowIndex);
            var sCategory = oRowContext.getObject().Category;
            var sRefDocno = oRowContext.getObject().RefDocno;

            // ȫѡ��ȡ��ȫѡ�ų�
            if (bSelectAll === true || iRowIndex < 0) {
                return;
            }

            // �ڴ��¼���ͨ���������õ�����ų�
            if (aRowIndices && aRowIndices[0] != iRowIndex) {
                return;
            }

            if (sCategory && parseInt(sCategory.substring(0, 2)) === 22) {
                for (var i = 0; i < iLength; i++) {

                    var oContext = oTable.getContextByIndex(i).getObject();
                    if (oContext && parseInt(oContext.Category.substring(0, 2)) === 22 && oContext.RefDocno == sRefDocno && i != iRowIndex) {
                        switch (bSelected) {
                        case true:
                            oTable = oTable.addSelectionInterval(i, i);
                            break;
                        case false:
                            oTable = oTable.removeSelectionInterval(i, i);
                            break;
                        default:
                            break;
                        }
                    }
                }
            }
        }

    });
});