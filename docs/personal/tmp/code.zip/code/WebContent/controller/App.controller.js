/*App������*/
sap.ui.define([
		"./BaseController",
		"./designMode",
		"sap/ui/model/json/JSONModel"
], function(BaseController, designMode, JSONModel) {
	"use strict";

	return BaseController.extend("yaluooFI01.controller.App", {
		
		// ��ʼ��
		onInit : function() {

		},

		onAfterRendering : function() {

			/*this.navTo(this.getRouterID());*/
			this.getRouter().navTo(this.getRouterID(window.location.hash), {}, true);

		},
		
		// ��ȡApp����
		getAppControl : function() {
			return this.byId("appNavContainer");
		}
	});
});