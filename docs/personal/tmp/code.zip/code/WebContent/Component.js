// �������������
sap.ui.define([
		"sap/ui/core/UIComponent",
		"sap/ui/model/resource/ResourceModel",
		"sap/ui/model/odata/v2/ODataModel",
		"sap/ui/Device",
		"./controller/messages",
		"./model/models"
], function(UIComponent, ResourceModel, ODataModel, Device, messages, models) {
	"use strict";
	return UIComponent.extend("yaluooFI01.Component", {
		metadata : {
			manifest : "json" },

		// ��ʼ������
		init : function() {
			var oContext = this;
			var oManifest = this.getMetadata().getManifest();
			var oDataSources = oManifest["sap.app"].dataSources;

			var localModel = models.createLocalModel();
			this.setModel(localModel);
			this.setModel(models.createDeviceModel(), "device");
			this.setModel(models.createFLPModel(), "FLP");
/*
			for ( var d in oDataSources) {

				if (oDataSources[d].type == "OData") {

					var name = d;
					var url = oDataSources[d].uri;

					this.setModel(models.createODataModel({
						urlParametersForEveryRequest : [
								"sap-server", "sap-client", "sap-language"
						],
						url : url,
						config : {
							useBatch : false,
							defaultCountMode : "None",
							disableSoftStateHeader : true,
							headers : {
								"ODataName" : name },
							json : true } })
							.attachMetadataLoaded(function(oEvent) {
						var oMetaData = oContext.getModel().getProperty("/ODataMetadata");
						var name = oEvent.getParameters().metadata.mHeaders.ODataName;
						oMetaData[name] = oEvent.getParameters().metadata;
						oContext.getModel().setProperty("/ODataMetadata", oMetaData, false)
					}).attachMetadataFailed(function(oEvent) {
						var sResponseText = oEvent.getParameters().responseText;
						var oResponseText = $.parseXML(sResponseText);
						var $ResponseText = $(oResponseText);
						var $message = $ResponseText.find("message");
						messages.showError($message.text());
					})
					, name);
				}
			}
*/
			var sRootPath = jQuery.sap.getModulePath("yaluooFI01");
			this.setModel(models.createResourceModel(sRootPath, oManifest["sap.app"].i18n), "i18n");
			UIComponent.prototype.init.apply(this, arguments);
			this.getRouter().initialize();
		},

		// �˳��������¼�
		destroy : function() {
//			this.getModel().destroy();
//			this.getModel("i18n").destroy();
//			this.getModel("FLP").destroy();
//			this.getModel("device").destroy();
//			this.getModel("OData").destroy();
			UIComponent.prototype.destroy.apply(this, arguments);
		} });
});
