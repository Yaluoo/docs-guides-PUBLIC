/*���ÿ�����*/
sap.ui.define([ "sap/ui/core/mvc/Controller", "sap/ui/core/UIComponent", "sap/ui/core/routing/History", "../model/formatter" ], function (Controller,
        UIComponent, History, formatter) {
    "use strict";

    return Controller.extend("yaluooFI01.controller.BaseController", {

        formatter : formatter,

        // ��ȡEventBus
        getEventBus : function () {
            return this.getOwnerComponent().getEventBus();
        },

        // ��ȡRouter(·��ʵ��)
        getRouter : function () {
            return UIComponent.getRouterFor(this);
        },

        // ��ȡRouterId(·��Id)
        /*
         * getRouterID : function() { var oHC = this.getRouter().oHashChanger; if (oHC.privgetCurrentShellHash) { var sHash =
         * oHC.privgetCurrentShellHash().hash; var s = oHC.privstripLeadingHash(sHash).split("-")[0]; s = s && s === "Shell-home" ? null : s; return
         * s; } },
         */
        getRouterID : function (sHash) {
            if (sHash == undefined) {
                return;
            }
            if (sHash) {
                sHash = sHash.replace("#", "");
            }
            if (sHash == "Shell-home") {
                return sHash;
            }
            var s = sHash.split("-")[0];
            s = s ? s : "Shell-home";
            return s;
        },

        // ��ת
        navTo : function (sName) {
            return sName == null ? null : this.getRouter().navTo(sName);
        },

        // ��app��ת
        crossAppNavTo : function (sViewId, aParams) {
            this.oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");

            if (!sViewId) {
                this.oCrossAppNav.backToPreviousApp();
                return;
            }
            this.oCrossAppNav.toExternal({
                target : {
                    semanticObject : sViewId,
                    action : "display",
                },
                params : aParams
            });
        },

        // ��ȡģ��
        getModel : function (sName) {
            return this.getView().getModel(sName) || this.getOwnerComponent().getModel(sName);
        },

        // ��ȡODataԪ����
        getODataMetadata : function (sName) {
            if (sName == "") {
                return null;
            }
            var oMetaData = this.getModel().getProperty("/ODataMetadata");
            return oMetaData[sName];
        },

        // ��ȡOData����EntityType
        getEntityTypeByName : function (sODataName, sEntityTypeName) {
            if (!this.getODataMetadata(sODataName)) {
                return null;
            }
            return this.getODataMetadata(sODataName)._getEntityTypeByName(sEntityTypeName);
        },

        // ����ģ��
        setModel : function (oModel, sName) {
            return this.getView().setModel(oModel, sName);
        },

        // ��ȡ��Դ��
        getResourceBundle : function () {
            return this.getOwnerComponent().getModel("i18n").getResourceBundle();
        },

        // ����busy״̬
        setBusy : function (b) {
            this.getModel().setProperty("/appProperties/busy", b);
        },

        // ����bcode��ֵ(ͬ����ʽ)
        setbcode : function (v) {
            this.getModel().setProperty("/appProperties/bcode", v, false);
        },

        // ��ȡbcode��ֵ
        getbcode : function (v) {
            return this.getModel().getProperty("/appProperties/bcode");
        },
        // ����hcode��ֵ(ͬ����ʽ)
        sethcode : function (v) {
            this.getModel().setProperty("/appProperties/hcode", v, false);
        },

        // ��ȡhcode��ֵ
        gethcode : function () {
            return this.getModel().getProperty("/appProperties/hcode");
        },
        // ����fcode��ֵ(ͬ����ʽ)
        setfcode : function (v) {
            this.getModel().setProperty("/appProperties/fcode", v, false);
        },

        // ��ȡfcode��ֵ(ͬ����ʽ)
        getfcode : function () {
            return this.getModel().getProperty("/appProperties/fcode");
        },

        // �Ƿ���E������Ϣ
        isError : function (oContext) {
            var iCounterE = oContext.getModel().getProperty("/messages/counterE");
            return iCounterE > 0 ? true : false;
        },

        // ҳ�����Ͻ�message��ť����
        openMessagePopover : function (oContext) {
            if (oContext._MessageButton && this.isError(oContext)) {
                oContext._MessageButton.firePress();
            }
        },

        // ������Ϣ����
        updateObligatory : function () {
            var oObligatory = {};
            var aReturn = this.getModel().getProperty("/returns");
            for (var i = 0; i < aReturn.length; i++) {
                if (aReturn[i].MessageV1 != "" && aReturn[i].Type == "E") {

                    var oR = {
                        Id : aReturn[i].Id,
                        LogMsgNo : aReturn[i].LogMsgNo,
                        LogNo : aReturn[i].LogNo,
                        Message : aReturn[i].Message,
                        MessageV1 : aReturn[i].MessageV1,
                        MessageV2 : aReturn[i].MessageV2,
                        MessageV3 : aReturn[i].MessageV3,
                        MessageV4 : aReturn[i].MessageV4,
                        Number : aReturn[i].Number,
                        Row : aReturn[i].Row,
                        System : aReturn[i].System
                    };

                    if (aReturn[i].MessageV2 != "") {
                        if (!oObligatory[aReturn[i].MessageV1]) {
                            oObligatory[aReturn[i].MessageV1] = {};
                        }
                        oObligatory[aReturn[i].MessageV1][aReturn[i].MessageV2] = oR;
                    }

                    if (aReturn[i].MessageV2 == "") {
                        oObligatory[aReturn[i].MessageV1] = oR;
                    }

                }
            }
            this.getModel().setProperty("/verReturn", oObligatory, false);

        },

        // �������ϱ������״̬���
        clearInputRequiredErrorStatus : function (oEvent) {
            var sRootPath = "/verReturn";
            var sPath = oEvent.getSource().getBinding("valueState").sPath;
            if (sPath == "") {
                var aBindings = oEvent.getSource().getBinding("valueState").aBindings;
                sPath = aBindings[0].sPath + "/" + aBindings[1].oValue;
            }
            var oVerReturn = this._JSONModel.getProperty(sRootPath);
            sPath = sPath.replace(sRootPath + "/", "");
            var aKey = sPath.split("/", 2);
            if (aKey.length == 1) {
                delete oVerReturn[aKey[0]];
            }
            if (aKey.length == 2) {
                delete oVerReturn[aKey[0]][aKey[1]];
                // �����д���״̬�޷��Զ��ÿգ���ǿ������
                oEvent.getSource().setValueState("None");
            }
            this._JSONModel.setProperty(sRootPath, oVerReturn, false);
        },

        // ��ȡҳ��ľۺ�����
        getPage : function () {
            var oView = this.getView();
            if (oView.getMetadata()._sClassName != "sap.ui.core.mvc.XMLView") {
                return null;
            }
            if (!oView.getContent() || oView.getContent().length == 0) {
                return null;
            }
            if (oView.getContent()[0].getMetadata()._sClassName != "sap.m.Page") {
                return null;
            }
            return oView.getContent()[0];
        },

        // ����32λ�����
        createGUID : function () {
            var g = "";
            var i = 32;
            while (i--) {
                g += Math.floor(Math.random() * 16.0).toString(16);
            }
            return g;
        },

        // ��д��¡����
        clone : function (obj, sub) {
            var o;
            if (obj.constructor == Object) {
                o = new obj.constructor();
            } else {
                o = new obj.constructor(obj.valueOf());
            }
            for ( var key in obj) {
                if (o[key] != obj[key]) {
                    if (typeof (obj[key]) == 'object') {
                        o[key] = this.clone(obj[key]);
                    } else {
                        o[key] = obj[key];
                    }
                }
            }
            o.toString = obj.toString;
            o.valueOf = obj.valueOf;
            return o;
        },

        // �����¼�
        onNavBack : function () {
            if (History.getInstance().getPreviousHash() !== undefined) {
                history.go(-1);
            } else {
                this.getRouter().navTo("", {}, true);
            }
        }

    });
});