// Utility for formatting values

sap.ui.define([
		"sap/ui/core/format/DateFormat", "sap/ui/core/format/NumberFormat", "sap/ui/core/Component"
], function(DateFormat, NumberFormat, Component) {
	"use strict";

	// ��ȡ��Դ��
	function fnGetBundle(oControl) {
		return (oControl.getModel("i18n") || sap.ui.component(Component.getOwnerIdFor(oControl)).getModel("i18n"))
				.getResourceBundle();
	}

	var fnDateAgoFormatter = DateFormat.getDateInstance({
		style : "medium",
		strictParsing : true,
		relative : true }), fnAmountFormatter = NumberFormat.getCurrencyInstance(), fnDeliveryDateFormatter = DateFormat
			.getDateInstance({
				style : "medium" });

	var me = {

	  // ת��UIC����
		convertUIC : function(aUIC) {
			if (!jQuery.isArray(aUIC)) {
				return;
			}
			var oUIC = {};
			for (var i = 0; i < aUIC.length; i++) {
				var sAttr = aUIC[i].Ueid;
				oUIC[sAttr] = {
					Setf : aUIC[i].Setf,
					Visible : aUIC[i].Visible,
					Editable : aUIC[i].Editable,
					Require : aUIC[i].Require };
			}
			return oUIC;
		},

		// ����Ԫ��VER����(Visible,Editable,Require)
		setElementVER : function(v) {
			if (v) {
				return v;
			}
			return false;
		},

		// ����Ԫ��״̬����(valueState)
		setElementVERvS : function(r) {
			if (r) {
				return "Error";
			}
			return "None";
		},

		// ����Table����Ԫ��VERS����(Visible,Editable,Require,valueState)
		setElementTVERvS : function(r, g) {
			if (r && r[g]) {
				return "Error";
			}
			return "None";
		},
		
		// ���ڸ�ʽ��
		dateString : function(value){
			if (value != "" && value != null){
				if(value == "00000000"){
					value = "";
					return value;
				}
			var year = value.substring(0,4);
			var month = value.substring(4,6);
			var day = value.substring(6,8);
			return year+"-"+month+"-"+day;
			}else{
				value = "";
				return value;
			}
		},
		
		// ʱ���ʽ��
		timeString : function(value){
			if (value != "" && value != null){
			var hour = value.substring(0,2);
			var minute = value.substring(2,4);
			var seconds = value.substring(4,6);
			return hour+":"+minute + ":"+seconds;
			}else{
				return value;
			}
		},
		
		// ���ڸ�ʽ��
		dateStringWithWeek : function(value){
			if (value != "" && value != null){
				if(value == "00000000"){
					return "";
				}
			var year = value.substring(0,4);
			var month = value.substring(4,6);
			var day = value.substring(6,8);
			var date = new Date(year + "-" + month + "-" + day);
			var week = me.convertToChinese(date.getDay());
			return year + "-" + month + "-" + day + '/' + week;
			}else{
				return "";
			}
		},
        
		
		convertToChinese:  function (num){
			switch(num){
				case 0:
					return '������';
				 break;
				case 1:
					return '����һ';
					break;
				case 2:
					return '���ڶ�';
					break;
				case 3:
					return '������';
					break;
				case 4:
					return '������';
					break;
				case 5:
					return '������';
					break;
				case 6:
					return '������';
					break;
				default:
				 break;
			}
		},
		
		getUTCtime : function (date) {

			var UTCyear = date.getUTCFullYear();
			var UTCmonth = date.getUTCMonth() + 1;
		    var UTCday = date.getUTCDate();
			var UTCtimeStr = UTCyear + "/" + UTCmonth + "/" + UTCday ;
		    return new Date(UTCtimeStr);
		},
		
		// ���ڣ���ԭ�����ڻ����ϣ�����days������Ĭ������1��
		addDate : function (date, days) {
            var date = new Date(date);
            if(days == 0){
            	date.setDate(date.getDate());
            }else{
            	date.setDate(date.getDate(),days);
            }
            var month = date.getMonth() + 1;
            var day = date.getDate();
            return new Date(date.getFullYear() + '-' + this.getFormatDate(month) + '-' + this.getFormatDate(day));
        },

        // �����·�/�����ʾ�������1λ��������ǰ�����'0'
        getFormatDate: function (arg) {
            if (arg == undefined || arg == '') {
                return '';
            }

            var re = arg + '';
            if (re.length < 2) {
                re = '0' + re;
            }

            return re;
        },
		// ȥ����
		deleteRightZero : function(v)// ȥ����
		{
			if (v === null || v === undefined || v === 0 || v === "0") {
				v = 0;
			}
			return parseFloat(v);
		},

		// ȥǰ����
		deleteLeftZero : function(v)// ȥǰ����
		{
			if (v === null || v === undefined || v === 0 || v === "0") {
				v = "0";
			}
			return v.replace(/^0+/, "");
		},

		// չʾ��Ϣ
		showMessage : function(v) {
			if (v > 0) {
				return true;
			}
			return false;
		},

		daysAgo : function(dDate) {
			if (!dDate) {
				return "";
			}
			return fnDateAgoFormatter.format(dDate);
		},
		
		// ʱ���ʽ��
		customTime : function(value) {
			if (value && value.ms) {
				var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
					pattern : "HH:mm:ss" });
				var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
				var timeStr = timeFormat.format(new Date(value.ms + TZOffsetMs));

				return timeStr;
			}
		},
		
		// ��ǰ���ڸ�ʽ��string����
		yyyymmdd : function(day){
			var mm = day.getMonth() + 1 ;
			var dd = day.getDate();
			return [day.getFullYear(),
					(mm > 9 ? '' : '0') + mm,
					(dd > 9 ? '' : '0') + dd].join('');
		},
		
		// ���ڸ�ʽ��
		date : function(value) {
			if (value) {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					pattern : "yyyyMMdd" });
				return oDateFormat.format(new Date(value));
			}
			else {
				return value;
			}
		},
		
		// �����͸�ʽ��
		formatToInt : function(v){
			if(v == 0 || v == undefined){
				return 0;
			}
			return parseInt(v);
		},
		
		checkBoxSelected : function(v) {
			return Boolean(v);
		},

		getElementVER : function(v) {
			if (v) {
				return v;
			}
			return false;
		},

		getElementVERvS : function(r) {
			if (r) {
				return "Error";
			}
			return "None";
		},

		getElementTVERvS : function(r, g) {
			if (r[g] != undefined) {
				return "Error";
			}
			return "None";
		},

	 };

	return me;
});