sap.ui.define([
		"sap/ui/model/Filter",
		"../controller/messages",
		"./models",
		"./formatter"
], function(Filter, messages, models, formatter) {
	"use strict";

	return {

		doPost : function(oView, fnSuccess, fnError) {
			this._Controller = oView.getController();
			this._JSONModel = this._Controller.getModel();
			var sBCode = this._JSONModel.getProperty("/appProperties/bcode");


			var f1 = "postDP"; // ��֧����
			var f2 = "postDPQ"; // ��֧����
			var sFunction = {

				"DP" : f1,
				"DPQ" : f2,
			}[sBCode] || "";

			switch (sFunction) {
			case f1:
				this.postDP(oView, fnSuccess, fnError);
				break;
			case f2:
				this.postDPQ(oView, fnSuccess, fnError);
				break;
			default:
				break;
			}
		},
		
		
		// ��ʱ��¼����
		postDP : function(oView, fnSuccess, fnError) {

			this._Controller = oView.getController();
			this._ODataModel = this._Controller.getModel("yaluooFI01");
			this._JSONModel = this._Controller.getModel();
			var sFCode = this._JSONModel.getProperty("/appProperties/fcode");// ����fcode
			this._Controller.setBusy(true);
			var oDP = this._JSONModel.getData().dpSet;
			var oRequest = this._Controller.clone(oDP);
			// �������Ŀ
			oRequest.Fcode = sFCode;
		
			oRequest.np_dp2ms = !oRequest.np_dp2ms ? [] : oRequest.np_dp2ms;
			if(oRequest.np_dp2ms[0]){
				if(oRequest.np_dp2ms[0].length == 0){
					oRequest.np_dp2ms = [];
				}
			}
			var sUrl = "/dpSet";
			var mParameters = {
				success : function(oData, response) {
					var localData = this._JSONModel.getData();
					
					localData.dpSet = oData;
					localData.dpSet.np_dp2ms = oData.np_dp2ms != null ? oData.np_dp2ms.results : null;
					this._JSONModel.setProperty("/", localData, false);
					messages.convertMessage(this, "/dpSet/np_dp2ms");
					
					this._Controller.setBusy(false);
					if (fnSuccess) {
						fnSuccess(this._Controller);
					}
				}.bind(this),
				error : function(oError) {
					this._Controller.setBusy(false);
					this._Controller.oError = oError;
					messages.convertODataErrorMessage(this._Controller);
					this._Controller.updateObligatory();
					if (fnError) {
						fnError(this._Controller);
					}
				}.bind(this)
			};
			this._ODataModel.create(sUrl, oRequest, mParameters);

		},
		
		// ��ʱ��¼����
		postDPQ : function(oView, fnSuccess, fnError) {

			this._Controller = oView.getController();
			this._ODataModel = this._Controller.getModel("yaluooFI01");
			this._JSONModel = this._Controller.getModel();
			var sFCode = this._JSONModel.getProperty("/appProperties/fcode");// ����fcode
			this._Controller.setBusy(true);
			var oDPQ = this._JSONModel.getData().dpqSet;
			var oRequest = this._Controller.clone(oDPQ);
			// �������Ŀ
			oRequest.Fcode = sFCode;
		
			oRequest.np_dpq2ms = !oRequest.np_dpq2ms ? [] : oRequest.np_dpq2ms;
			if(oRequest.np_dpq2ms[0]){
				if(oRequest.np_dpq2ms[0].length == 0){
					oRequest.np_dpq2ms = [];
				}
			}
			oRequest.np_dpq2fi05 = !oRequest.np_dpq2fi05 ? [] : oRequest.np_dpq2fi05;
			if(oRequest.np_dpq2fi05[0]){
				if(oRequest.np_dpq2fi05[0].length == 0){
					oRequest.np_dpq2fi05 = [];
				}
			}
			var sUrl = "/dpqSet";
			var mParameters = {
				success : function(oData, response) {
					var localData = this._JSONModel.getData();
					
					localData.dpqSet = oData;
					localData.dpqSet.np_dpq2fi05 = oData.np_dpq2fi05 != null ? oData.np_dpq2fi05.results : null;
					localData.dpqSet.np_dpq2ms = oData.np_dpq2ms != null ? oData.np_dpq2ms.results : null;
					this._JSONModel.setProperty("/", localData, false);
					messages.convertMessage(this, "/dpqSet/np_dpq2ms");
					
					this._Controller.setBusy(false);
					if (fnSuccess) {
						fnSuccess(this._Controller);
					}
				}.bind(this),
				error : function(oError) {
					this._Controller.setBusy(false);
					this._Controller.oError = oError;
					messages.convertODataErrorMessage(this._Controller);
					this._Controller.updateObligatory();
					if (fnError) {
						fnError(this._Controller);
					}
				}.bind(this)
			};
			this._ODataModel.create(sUrl, oRequest, mParameters);

		},
		
		
		// ��ȡDomainֵ��������
		getDomainValueList : function(sDomainName, oContext, sLanguage) {
			var aFilters = [];
			aFilters.push(new Filter("Domname", sap.ui.model.FilterOperator.EQ, sDomainName));
			aFilters.push(new Filter("Ddlanguage", sap.ui.model.FilterOperator.EQ, sLanguage));
			this.callSearchHelp("ZSH_DOMAIN", oContext, aFilters);
		},

		// ����������������
		callSearchHelp : function(sName, oController, aFilter, aSorter, fnSuccess, fnError) {

			this._Controller = oController;
			this._ODataModel = this._Controller.getModel("yaluooFI01");
			this._JSONModel = this._Controller.getModel();

			this._Controller.setBusy(true);

			sName = sName + "Set";
			var sUrl = "/" + sName;
			var iQueryMaxhints = this._JSONModel.getProperty("/appProperties/queryMaxhints");
			if (iQueryMaxhints == "" || iQueryMaxhints == 0) {
				iQueryMaxhints = 9999;
			}

			if (sName == "ZSH_DOMAINSet") {
				if (!aFilter || !aFilter.length || aFilter.length == 0) {
					return;
				}
				for (var i = 0; i < aFilter.length; i++) {
					if (aFilter[i].sPath == "Domname") {
						sName = aFilter[i].oValue1 + "Set";
					}
				}
			}

			var mParameters = {
				urlParameters : {
					$top : iQueryMaxhints,
					$skip : 0
				},
				filters : aFilter,
				sorters : aSorter,
				success : function(oData, response) {
					var localData = this._JSONModel.getData();
					localData[sName] = oData.results;
					this._JSONModel.setProperty("/", localData, false);
					this._Controller.setBusy(false);
					if (fnSuccess) {
						fnSuccess(this._Controller);
					}
				}.bind(this),
				error : function(oError) {
					this._Controller.setBusy(false);
					this._Controller.oError = oError;
					if (fnError) {
						fnError(this._Controller);
					}
				}.bind(this)
			};

			this._ODataModel.read(sUrl, mParameters);

		},

	
		// �����ϴ����ݽ�����������
		postAttachment : function(oView, fnSuccess, fnError) {
			this._Controller = oView.getController();
			this._JSONModel = this._Controller.getModel();
			this._ResourceBundle = this._Controller.getModel("i18n").getResourceBundle();

			// this.setBusy(true);

			if (this.atODataModel == undefined) {
				this.atODataModel = models.createODataModel({
					urlParametersForEveryRequest : [
							"sap-server",
							"sap-client",
							"sap-language"
					],
					url : "/sap/opu/odata/sap/ZXXFILE01_SRV/",
					config : {
						// metadataUrlParams: {
						// "sap-documentation": "heading"
						// },
						// defaultBindingMode: "OneWay",
						useBatch : false,
						defaultCountMode : "None",
						// loadMetadataAsync: true,
						json : true
					}
				});
			}

			var oRequest = this._JSONModel.getData().filelistSet;

			for ( var o in oRequest) {
				if (oRequest[o] == null) {
					oRequest[o] = [];
				}
			}

			if (oRequest.np_filelist2h.length == 0) {
				var np_attah = {
					Docid : "",
					Filename : "",
					Mimetype : "",
					Url : "",
					np_attah2a : []
				};
				oRequest.np_filelist2h.push(np_attah);
			}

			this._Controller.setBusy(true);

			var sUrl = "/filelistSet";
			var mParameters = {
				success : function(oData, response) {
					this._Controller.setBusy(false);
					var localData = this._JSONModel.getData();
					localData.filelistSet = oData;
					localData.filelistSet.np_filelist2bt = oData.np_filelist2bt != null ? oData.np_filelist2bt.results : null;
					localData.filelistSet.np_filelist2h = oData.np_filelist2h != null ? oData.np_filelist2h.results : null;
					if (localData.filelistSet.np_filelist2h != null) {
						for (var i = 0; i < localData.filelistSet.np_filelist2h.length; i++) {
							localData.filelistSet.np_filelist2h[i].np_attah2a = localData.filelistSet.np_filelist2h[i].np_attah2a != null ? localData.filelistSet.np_filelist2h[i].np_attah2a.results : null;
						}
					}
					this._JSONModel.setProperty("/", localData, false);

					if (oRequest.Fcode == "DELETE") {
						messages.showText(this._ResourceBundle.getText("fileDel.Ok"));
					}
				}.bind(this),
				error : function(oError) {
					this._Controller.setBusy(false);
					if (oRequest.Fcode == "DELETE") {
						messages.showText(this._ResourceBundle.getText("fileDel.Error"));
					}
					this._JSONModel.setProperty("/filelistSet/Fcode", "SELECT");
					this.postAttachment(oView);

				}.bind(this)
			};
			this.atODataModel.create(sUrl, oRequest, mParameters);
		},
	};
});